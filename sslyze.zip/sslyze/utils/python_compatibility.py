import sys

IS_PYTHON_2 = sys.version_info < (3, 0)
